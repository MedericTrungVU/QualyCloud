<?php namespace App\Http\Controllers;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Account;
use App\User;
use Illuminate\Support\Facades\DB;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Request;


class ComptesController extends Controller {

    public function recupererInfos()
    {
        $account = Account::with('user')->get();

        return $account;
    }

    public function recupererClients()
    {
        $username = DB::table('accounts')->where('insurance_entreprise', 'AXA')->value('email');
        $password = DB::table('accounts')->where('insurance_entreprise', 'AXA')->value('password');
        $client = new Client();
        $res1 = $client->request('POST', 'https://demo.qualytrust.com/api/auth/login/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87', [
            'form_params' => [
                'login' => $username,
                'password' => $password,
            ]
        ]);
        $result1 = $res1->getBody();
        $data = json_decode($result1,true);
        $mots = $data["data"]["token"];

        // faire une demande pour récupérer des clients
        $res2 = $client->request('GET', "https://demo.qualytrust.com/api/ins_folders/list/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87/?token=$mots");
        $result2 = $res2->getBody();
        $data2 = json_decode($result2,true);

        return $result2;
    }

    /**
    public function recupererContracts()
    {

        $username = DB::table('accounts')->where('insurance_entreprise', 'AXA')->value('email');
        $password = DB::table('accounts')->where('insurance_entreprise', 'AXA')->value('password');
        $client = new Client();
        $res1 = $client->request('POST', 'https://demo.qualytrust.com/api/auth/login/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87', [
            'form_params' => [
                'login' => $username,
                'password' => $password,
            ]
        ]);
        $result1 = $res1->getBody();
        $data = json_decode($result1,true);
        $mots = $data["data"]["token"];

        // faire une demande pour récupérer des clients
        $res2 = $client->request('GET', "https://demo.qualytrust.com/api/ins_files/list/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87/folder/8/?token=$mots");
        $result2 = $res2->getBody();
        $data2 = json_decode($result2,true);

        return $result2;
    }
     */

    /**
     *
     */
}