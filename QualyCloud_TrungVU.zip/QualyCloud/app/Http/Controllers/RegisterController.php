<?php namespace App\Http\Controllers;

//use Auth;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesResources;
//use DB;
use GuzzleHttp\Client;
use Illuminate\Http\Request;

class RegisterController extends Controller {

    public function showRegister()
    {
        return view('register');
    }

    /**
     *
     */
    public function doRegister(Request $req)
    {
        /**
        $credentials = $req->only(['email', 'password']);
        $username = $req->input('email');
        $password = $req->input('password');
        $checkLogin = DB::table('users')->where(['email'=>$username,'password'=>$password])->get();

        if( count($checkLogin)>0 ) {
            return view('thanks');
        }
        return $credentials;
         */

        $credentials = $req->only(['email', 'password']);
        $email=$req->email;
        $password=$req->password;

        if(Auth::attempt(['email'=>$email,'password'=>$password]))
        {
            return view('index');
        }
        return $credentials;


        /**
        $client = new Client();
        $res1 = $client->request('POST', 'https://demo.qualytrust.com/api/auth/login/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87', [
            'form_params' => [
                'login' => $username,
                'password' => $password,
            ]
        ]);
        $result1 = $res1->getBody();
        $data = json_decode($result1,true);
        $mots = $data["data"]["token"];

        // faire une demande pour récupérer des contrats
        $res2 = $client->request('GET', "https://demo.qualytrust.com/api/ins_folders/list/QC-API-KEY/0bd18c3284a400c215afb8dd4e96c753a1594d87/?token=$mots");
        $result2 = $res2->getBody();
        $data2 = json_decode($result2,true);

        return $result1."<br>".$result2;
         */
    }
}