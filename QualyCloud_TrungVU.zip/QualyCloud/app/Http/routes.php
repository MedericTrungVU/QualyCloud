<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//    return view('welcome');
// });

/*
'/api'),function(){

Route::post('login/auth','UserController@Login'); ////////////////////////route for login
Route::get('login/destroy','UserController@Logout');/////////////////////route for logout
Route::post('/register','UserController@create');///////////////////////route for register

Route::resource('posts','PostController');/////////////////////////////single route for post add, edit delete, find all

});
*/

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the Closure to execute when that URI is requested.
|
*/

Route::get('/register', 'RegisterController@showRegister');
Route::post('/register', 'RegisterController@doRegister');

Route::get('/comptes', 'ComptesController@recupererInfos');
Route::get('/axa/clients', 'ComptesController@recupererClients');
Route::get('/axa/contracts', 'ComptesController@recupererContracts');
/*
Route::post('/login', function()
{
    $credentials = Input::only('username', 'password');

    $user = new User;
    //$user->email = Input::get('email');
    $user->username = Input::get('username');
    $user->password = Hash::make(Input::get('password'));

    $userdata = array(
        'username'=>$user->username,
        'password'=>$user->password
    );

    $res = Auth::attempt($userdata);
    $converted_res = ($res) ? 'true' : 'false';
    return $converted_res;
    //if (Auth::attempt($credentials)) {
    //	return Redirect::intended('/');
    //}t
    //return Redirect::to('login');
});

Route::get('/logout', function()
{
    Auth::logout();
    return View::make('logout');
});

Route::get('/spotlight', array(
    'before' => 'auth',
    function()
    {
        return View::make('spotlight');
    }
));
*/


