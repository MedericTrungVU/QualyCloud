<?php



use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Account;


class DatabaseSeeder extends Seeder {

    public function run()
    {
        Model::unguard();

        // Call the seed classes to run the seeds
        $this->call('UsersTableSeeder');
        $this->call('AccountsTableSeeder');
    }

}

class UsersTableSeeder extends Seeder {

    public function run()
    {

        // We want to delete the users table if it exists before running the seed
        DB::table('users')->delete();

        $users = array(
            ['email' => 'thiem@gmail.com', 'password' => Hash::make('secret'), 'number_of_accounts' => 2],
        );

        // Loop through each user above and create the record for them in the database
        foreach ($users as $user)
        {
            User::create($user);
        }
    }
}

class AccountsTableSeeder extends Seeder {

    public function run()
    {
        DB::table('accounts')->delete();

        $accounts = array(
            ['user_id' => 1, 'email' => 'corentin@qualytrust.com', 'password' => 'qualycloud',
                'clefAPI' => '0bd18c3284a400c215afb8dd4e96c753a1594d87', 'insurance_entreprise' => 'AXA'],
            ['user_id' => 1, 'email' => 'jean@qualytrust.com', 'password' => 'qualycloud',
                'clefAPI' => '0bd18c3284a400c215afb8dd4e96c753a1594d87', 'insurance_entreprise' => 'Generali'],
        );

        foreach($accounts as $account)
        {
            Account::create($account);
        }

    }
}

