<?php
/**
 * Created by PhpStorm.
 * User: vuthanhtrung
 * Date: 2017-04-25
 * Time: 14:00
 */
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder {

    public function run()
    {
        /**
        DB::table('users')->truncate();
        $faker = Faker\Factory::create();
        $utilisateurs = [];

        foreach (range(1,20) as $index)
        {
            $utilisateurs[] = [
                'email' => $faker->unique->email,
                'password' => $faker->word,
                'remember_token' => str_random(60)
            ];
        }

        DB::table('users')->insert($utilisateurs);
        */
        DB::delete('delete from users');
    }
}