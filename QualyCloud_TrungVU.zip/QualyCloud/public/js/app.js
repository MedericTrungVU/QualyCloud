/**
 * Created by vuthanhtrung on 2017-06-16.
 */
(function() {

var app = angular.module('ComptesCtrl', []);
app.controller('ComptesController', ['$http', function ($http) {

    var courtier = this;
    courtier.dossiers_fermees = [];
    courtier.dossiers_valides = [];
    courtier.dossiers_ouverts = [];
    courtier.dossiers = gems;

   courtier.comptes = [];
    courtier.clients = [];
    courtier.contracts = [];
    courtier.tab = 0;
    courtier.compteur1 = 0;
    courtier.compteur2 = 0;

    courtier.the = 0;
    courtier.setThe = function (tabId) {
        courtier.the = tabId;
    };

    courtier.isThe = function (tabId) {
        return courtier.the === tabId;
    };


    courtier.setTab = function (tabId) {
  courtier.tab = tabId;
 };

 courtier.isSet = function (tabId) {
  return courtier.tab === tabId;
 };

    courtier.onglet = 5;
    courtier.setOnglet = function (tabId) {
        courtier.onglet = tabId;
    };

    courtier.isOnglet = function (tabId) {
        return courtier.onglet === tabId;
    };


 courtier.logNewTime = function () {
     courtier.tab = 2;
     /* the $http service allows you to make arbitrary ajax requests.
      * in this case you might also consider using angular-resource and setting up a
      * User $resource. */
     $http.get('comptes').success(function (data) {
         courtier.comptes = data;
     });
 };
    courtier.table_data = [];
    courtier.table_data_unique=[];
    courtier.getClients2 = function () {
        courtier.compteur2+=1;
        if (courtier.compteur2%2==1)
            courtier.tab = 14;
        else
            courtier.tab = 222;
        };

     courtier.getClients1 = function () {
         courtier.compteur1+=1;
         if (courtier.compteur1%2==1)
            courtier.tab = 12;
         else
             courtier.tab = 122;

         $http.get('axa/clients').success(function (data) {
             courtier.clients = data.data.folders;
         });

         for (var i = 0; i < courtier.clients.length; i++) courtier.table_data.push({
             name: courtier.clients[i].member.identity,
             socialID: courtier.clients[i].member.socialId,
             organization: (courtier.clients[i].member.organizationName === null ? 'individuel' : courtier.clients[i].member.organizationName),
             status: (courtier.clients[i].currentStep === 'new_folder' ? 'Adhérent en cours de validation' : 'Adhérent actif')

         });

         for (var a=0; a < courtier.table_data.length; a++) {
             if (a===0)
                 courtier.table_data_unique.push(courtier.table_data[a]);
             else {
                 if (courtier.table_data_unique[courtier.table_data_unique.length - 1].name !== courtier.table_data[a].name) {
                     courtier.table_data_unique.push(courtier.table_data[a]);
                 }
             }
         }
         for (var n=0; n < courtier.dossiers.length; n++) {
             if (courtier.dossiers[n].status==='dossier classé sans suite')
                 courtier.dossiers_fermees.push(courtier.dossiers[n]);
             else if (courtier.dossiers[n].status==='validé')
                 courtier.dossiers_valides.push(courtier.dossiers[n]);
             else
                 courtier.dossiers_ouverts.push(courtier.dossiers[n]);
         }
     };


}]);


    app.controller('ReviewController', function() {
        this.review = {};

        this.addReview = function(comptes) {
            comptes.push(this.review);

            this.review = {};
        };
    });



    var gems = [
        {
            name: 'Adèle ALLARD',
            status: "dossier classé sans suite",
            id: "123456pat - 50 SOLO PREV",
            creation: "2015-06-09 11:11:58",
            Maj: "2015-06-09 11:11:58",
            documents: [
                "MANDAT SEPA.docx",
                "bulletin_adhesion_dynamique.pdf",
                "QMS_Remplissable.pdf"
            ]
        }, {
            name: 'Adèle ALLARD',
            status: "validé",
            id: "prema654321 - 50 SOLO PREV",
            creation: "2015-06-09 11:24:49",
            Maj: "2015-06-09 12:28:37",
            documents: [
            "MANDAT SEPA.docx",
            "bulletin_adhesion_dynamique.pdf",
            "QMS.pdf"
            ]
        }, {
            name: 'Patricia Moragas',
            status: "validé",
            id: "pm123456 - 50 SOLO PREV",
            creation: "2015-06-09 12:46:13",
            Maj: "2015-06-10 11:28:21",
            documents: [
                "MANDAT SEPA.docx",
                "bulletin_adhesion_dynamique.pdf",
                "QMS.pdf",
                "radio main.gif"
            ]
        }, {
            name: 'Johnny Hallyday',
            status: "nouveau contrat",
            id: "123456PREV - 50 SOLO PREV",
            creation: "2015-06-09 19:46:17",
            Maj: "2015-06-09 19:46:17",
            documents: [
                "BA.pdf",
                "QMS.pdf"
            ]
        }, {
            name: 'Charles Pompei',
            status: "nouveau contrat",
            id: "741852pat - 50 SOLO PREV",
            creation: "2015-06-09 18:01:08",
            Maj: "2015-06-09 18:01:08",
            documents: [
                "Mod_certificat_independants.pdf",
                "bulletin_adhesion_dynamique.pdf",
                "QMS.pdf"
            ]
        }, {
            name: 'Thomas AZAEL',
            status: "nouveau contrat",
            id: "COL1234 - 40 ET PLUS PREV",
            creation: "2015-06-10 10:57:26",
            Maj: "2015-06-10 10:57:26",
            documents: [
                "BA.pdf"
            ]
        }, {
            name: 'Kevin MARTINO',
            status: "salarié",
            id: "COL1234MLR7 - 40 ET PLUS PREV : Salarié",
            creation: "2015-06-10 11:15:20",
            Maj: "2015-06-10 11:21:19",
            documents: [
                "BA.pdf"
            ]
        }, {
            name: 'Kevin MARTINO',
            status: "nouveau contrat",
            id: "COL12344CQR - 40 ET PLUS PREV : Salarié",
            creation: "2015-06-10 11:18:52",
            Maj: "2015-06-10 11:18:52",
            documents: [
            ]
        }
    ];


})();
/**
var app = angular.module('blogApp',[
'ngRoute',
//Login
'LoginCtrl',
//Posts
//UserService
'UserCtrl',
//Auth Service
'AuthSrvc',
]);
app.run(function(){

});

//This will handle all of our routing
app.config(function($routeProvider, $locationProvider){

$routeProvider.when('/',{
templateUrl:'js/templates/login.html',
controller:'LoginController'
});
$routeProvider.when('/register',{
templateUrl:'js/templates/register.html',
controller:'UserController'
});
 });
*/