
var user = angular.module('UserCtrl',[]);
user.controller('UserController',function($scope,RegisterSrvc){

			$scope.submit = function(){
            var request = RegisterSrvc.user($scope.new);
                request.success(function(response){
                    $scope.flash = response.status;/////////display message
                });
        	}

});
