/**
 * Created by vuthanhtrung on 2017-06-16.
 */
var myApp = angular.module('ComptesCtrl', []);
myApp.controller('ComptesController', ['$scope', '$http', function ($scope, $http) {
    $scope.user = {};
    $scope.results = [];
    $scope.tab = 5;

    $scope.setTab = function (tabId) {
        $scope.tab = tabId;
    };

    $scope.isSet = function (tabId) {
        return $scope.tab === tabId;
    };
    $scope.logNewTime = function () {
        $scope.tab = 2;
        /* the $http service allows you to make arbitrary ajax requests.
         * in this case you might also consider using angular-resource and setting up a
         * User $resource. */
        $http.get('http://localhost:8000/comptes').success(function (data) {
            $scope.results = data;
        });
    };
}]);