var register = angular.module('RegisterSrvc',[]);
register.factory('Register',function($http){
var authUser = $http({method:'POST',url:'api/register',params:credentials});
return authUser;

});
