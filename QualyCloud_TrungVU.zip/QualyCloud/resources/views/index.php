<!doctype html>
<html ng-app="ComptesCtrl">
    <head>
        <title>Time Tracker</title>
        <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
        <!-- Application Dependencies -->
        <script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.15/angular.min.js"></script>

        <!-- Application Scripts -->
        <script type="text/javascript" src="js/app.js"></script>
        <style>
            .bottom-three {
                margin-bottom: 1cm;
            }

            .button {
                background-color: white;
                color: black;
                border: 2px solid #4CAF50; /* Green */
                margin-bottom: 0.5cm;
            }
        </style>


    </head>

  <body ng-controller="ComptesController as vm">
    <!--  Store Header  -->
    <header>
      <h1 class="text-center">Qualycloud</h1>
	</header>

	<div class="container">
     <h1>
      <button class='btn btn-primary pull-right'>Deconnexion</button>
    </h1>
	</div>

    <!-- Product Tabs  -->
    <div>
        <section>
            <ul class="nav nav-pills">
                <li ng-class="{ active:vm.isSet(1) }">
                    <a href ng-click="vm.setTab(1)">Espace personnel</a>
                </li>
                <li ng-class="{ active:vm.isSet(2) }">
                    <a href ng-click="vm.logNewTime()">Gestion des clients et contrats</a>
                </li>
            </ul>

            <!--  Review Tab's Content  -->
            <div class="list-group" ng-repeat="product in vm.comptes">
                <button type="button" ng-click=" product.insurance_entreprise === 'AXA' ? vm.getClients1() : vm.getClients2() "> {{'Compte chez ' + product.insurance_entreprise}} </button>

                <div ng-show="(product.insurance_entreprise === 'AXA' && vm.isSet(12)) || (product.insurance_entreprise === 'Generali' && vm.isSet(14))">
                <ul class="nav nav-pills">
                    <li ng-class="{ active:vm.isSet(3) }">
                        <a href ng-click="product.insurance_entreprise === 'AXA' ? vm.setThe(3) : vm.setThe(5)" class="bottom-three">Adherents</a>
                    </li>
                    <li ng-class="{ active:vm.isSet(4) }">
                        <a href ng-click="product.insurance_entreprise === 'AXA' ? vm.setThe(4) : vm.setThe(6)" class="bottom-three">Contrats</a>
                    </li>
                </ul>

                <div ng-show = " (vm.isThe(3) && product.insurance_entreprise === 'AXA') || (vm.isThe(5) && product.insurance_entreprise === 'Generali') ">
                    <table class="table table-bordered">
                        <thead>
                        <tr>
                            <th>Nom</th>
                            <th>Securite Social</th>
                            <th>Organization/Individuel</th>
                            <th>Etat</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr ng-repeat="review in vm.table_data_unique">
                            <td>{{review.name}}</td>
                            <td>{{review.socialID}}</td>
                            <td>{{review.organization}}</td>
                            <td>{{review.status}}</td>
                        </tr>
                        </tbody>
                    </table>
                    <form name="reviewForm" ng-controller="ReviewController as reviewCtrl" ng-submit="reviewCtrl.addReview(vm.table_data_unique)">


                        <!--  Review Form -->
                        <h4>Submit a Review</h4>
                        <fieldset class="form-group">
                            Nom: <textarea ng-model="reviewCtrl.review.name" class="form-control" placeholder="Write ..." title="Review1"></textarea>
                        </fieldset>
                        <fieldset class="form-group">
                            Securité social: <textarea ng-model="reviewCtrl.review.socialID" class="form-control" placeholder="Write ..." title="Review2"></textarea>
                        </fieldset>
                        <fieldset class="form-group">
                            Organization ou Individuel: <textarea ng-model="reviewCtrl.review.organization" class="form-control" placeholder="Write ..." title="Review3"></textarea>
                        </fieldset>
                        <fieldset class="form-group">
                            État de client: <textarea ng-model="reviewCtrl.review.status" class="form-control" placeholder="Write ..." title="Review4"></textarea>
                        </fieldset>
                        <fieldset class="form-group">
                            <input type="submit" class="btn btn-primary pull-right" value="Submit Review" />
                        </fieldset>
                    </form>
                </div>

                        <div class="row" ng-show = "(vm.isThe(4) && product.insurance_entreprise === 'AXA') || (vm.isThe(6) && product.insurance_entreprise === 'Generali')">
                            <div class="col-sm-2">
                                    <button class="button" ng-click="vm.setOnglet(100)">       Dossier à traiter       </button>
                                    <button class="button" ng-click="vm.setOnglet(101)">       Dossiers ouverts        </button>
                                    <button class="button" ng-click="vm.setOnglet(102)">       Dossiers validés        </button>
                                    <button class="button" ng-click="vm.setOnglet(103)">       Dossiers fermés         </button>
                            </div>

                            <div class="col-sm-10">
                                <div ng-show = "vm.isOnglet(100)">
                                    <p> Il y a aucun document </p>
                                </div>

                                <div ng-show = "vm.isOnglet(101)" ng-repeat="dossier in vm.dossiers_ouverts">
                                    <div class="row" style="background-color:#EDD2FB; border-bottom: 5px grey solid;">
                                        <div class="col-sm-5">
                                            <h4>{{dossier.status}} | {{dossier.id}}</h4>
                                            <p>{{dossier.name}}</p>
                                        </div>

                                        <div class="col-sm-7">
                                            <p>Date de Création: {{dossier.creation}}</p>
                                            <p>Date de mise à jour: {{dossier.Maj}}</p>
                                            <p><b> Document: <br /></b></p>
                                            <div style="margin-left: 0.5cm;" ng-repeat="paper in dossier.documents">
                                                <a href>{{paper}}</a>
                                            </div>
                                        </div>
                                </div>


                                </div>

                                <div ng-show = "vm.isOnglet(102)" ng-repeat="dossier in vm.dossiers_valides">
                                    <div class="row" style="background-color:#EDD2FB; border-bottom: 5px grey solid;">
                                        <div class="col-sm-5">
                                            <h4>{{dossier.status}} | {{dossier.id}}</h4>
                                            <p>{{dossier.name}}</p>
                                        </div>

                                        <div class="col-sm-7">
                                            <p>Date de Création: {{dossier.creation}}</p>
                                            <p>Date de mise à jour: {{dossier.Maj}}</p>
                                            <p><b> Document: <br /></b></p>
                                            <div style="margin-left: 0.5cm;" ng-repeat="paper in dossier.documents">
                                                <a href>{{paper}}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div ng-show = "vm.isOnglet(103)" ng-repeat="dossier in vm.dossiers_fermees">
                                    <div class="row" style="background-color:#EDD2FB; border-bottom: 5px grey solid;">
                                        <div class="col-sm-5">
                                            <h4>{{dossier.status}} | {{dossier.id}}</h4>
                                            <p>{{dossier.name}}</p>
                                        </div>

                                        <div class="col-sm-7">
                                            <p>Date de Création: {{dossier.creation}}</p>
                                            <p>Date de mise à jour: {{dossier.Maj}}</p>
                                            <p><b> Document: <br /></b></p>
                                            <div style="margin-left: 0.5cm;" ng-repeat="paper in dossier.documents">
                                                <a href>{{paper}}</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>

                        </div>
                </div>
                </div>
        </section>
    </div>

  </body>
</html>
