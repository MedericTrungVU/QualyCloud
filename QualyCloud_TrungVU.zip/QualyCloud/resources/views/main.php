<!doctype html>
<html lang="en">
<head>
<title>Blog Administration</title>
<!--css-->
<link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css"/>

<!--js-->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>

<!--angular-->

</head>
<div class="header">
    <ul>
        <li><a href="http://localhost/mylarvel/public/#/dashboard">Desboard</a></li>
        <li><a href="http://localhost/mylarvel/public/">Login</a></li>
        <li><a href="http://localhost/mylarvel/public/#/register">Register</a></li>
    </ul>
</div>
<body ng-app="blogApp">
 <div id="wrapper">
 <div class="container" id="view" ng-view>

 </div>
 <script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.15/angular.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/angularjs/1.2.15/angular-route.js"></script>

<script src="../../public/js/app.js"></script>
<script src="../../public/js/services/authService.js"></script>
<script src="../../public/js/controllers/loginController.js"></script>
<script src="../../public/js/controllers/UserController.js"></script>
<script src="../../public/js/controllers/postEditController.js"></script>
<script src="../../public/js/controllers/postController.js"></script>
<script src="../../public/js/services/authService.js"></script>
<script src="../../public/js/services/crudService.js"></script>

 </div>


</body>
</html>
