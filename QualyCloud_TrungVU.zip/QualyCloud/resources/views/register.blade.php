<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Qualycloud: Tout pour courties</title>
<link href="{{ asset('_css/main.css') }}" rel="stylesheet" media="screen, projection">
<meta name="viewport" content="initial-scale=1.0" />

</head>
<body id="blogPage">
<div id="contentWrapper">
  <article id="mainContent">
    <h1>Sign Up!</h1>
    <article class="post">
      <h2>User Registration</h2>
      <!-- form goes here -->
      {!! Form::open(array('url'=>'register', 'method'=>'POST', 'accept-charset'=>'UTF-8','files'=>true)) !!}

      {{ Form::label('email','Email') }}
      {!! Form::email('email') !!}

      {!! Form::label('password','Password') !!}
      {!! Form::password('password') !!}

       {{ Form::submit('Log In') }}

      {!! Form::close() !!}

</article>
  </article>
</div>

</body>
</html>
