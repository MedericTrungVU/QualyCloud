<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Qualycloud: Tout pour courties</title>
<link href="<?php echo e(asset('_css/main.css')); ?>" rel="stylesheet" media="screen, projection">
<meta name="viewport" content="initial-scale=1.0" />

</head>
<body id="blogPage">
<div id="contentWrapper">
  <article id="mainContent">
    <h1>Sign Up!</h1>
    <article class="post">
      <h2>User Registration</h2>
      <!-- form goes here -->
      <?php echo Form::open(array('url'=>'register', 'method'=>'POST', 'accept-charset'=>'UTF-8','files'=>true)); ?>


      <?php echo e(Form::label('email','Email')); ?>

      <?php echo Form::email('email'); ?>


      <?php echo Form::label('password','Password'); ?>

      <?php echo Form::password('password'); ?>


       <?php echo e(Form::submit('Log In')); ?>


      <?php echo Form::close(); ?>


</article>
  </article>
</div>

</body>
</html>
